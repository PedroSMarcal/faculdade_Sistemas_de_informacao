-- Inserindo os administradores
-- DESCRIBE users;
-- DESCRIBE admin;

INSERT INTO users (id, name, username, password)
VALUES (0, 'ADM Fulano', 'adm_fulano', 'senha123');

INSERT INTO users (id, name, username, password)
VALUES (1, 'ADM Ciclano', 'adm_ciclano', 'senha123');

INSERT INTO users (id, name, username, password)
VALUES (2, 'ADM Beltrano', 'adm_beltrano', 'senha123');

INSERT INTO admin (id, permission_create_admin)
VALUES (0, 1);

INSERT INTO admin (id, permission_create_admin)
VALUES (1, 0);

INSERT INTO admin (id, permission_create_admin)
VALUES (2, 1);

-- Inserindo os montadores
-- DESCRIBE users;
-- DESCRIBE assembler;

INSERT INTO users (id, name, username, password)
VALUES (3, 'Montador Fulano', 'mont_fulano', 'senha123');

INSERT INTO users (id, name, username, password)
VALUES (4, 'Montador Ciclano', 'mont_ciclano', 'senha123');

INSERT INTO users (id, name, username, password)
VALUES (5, 'Montador Beltrano', 'mont_beltrano', 'senha123');

INSERT INTO assembler (id, cellphone)
VALUES (3, '16123456789');

INSERT INTO assembler (id, cellphone)
VALUES (4, '16987654321');

INSERT INTO assembler (id, cellphone)
VALUES (5, '16000000000');

-- Inserindo os clientes
-- DESCRIBE customer;

INSERT INTO customer (id, send_contact_alert, name, phone, document, next_contact_date)
VALUES (0, 1, 'Cliente Fulano', '161237456789', '12345', '21/01/2021');

INSERT INTO customer (id, send_contact_alert, name, phone, document, next_contact_date)
VALUES (2, 0, 'Cliente Ciclano', '16987654321', '98765', '08/04/2021');

INSERT INTO customer (id, send_contact_alert, name, phone, document, next_contact_date)
VALUES (3, 1, 'Cliente Beltrano', '16000000000', '13795', '30/10/2021');

-- Inserindo os endereços
-- DESCRIBE address;

INSERT INTO address (
    id, cep, street, "number", complement, district, city, uf, country
) VALUES (
    0, '14401-000', 'Rua Angela', 000, 'Complemento', 'Aeroporto', 'Franca', 'SP', 'Brasil'
);

INSERT INTO address (
    id, cep, street, "number", complement, district, city, uf, country
) VALUES (
    1, '14401-111', 'Rua Fulano', 111, 'Complemento', 'Centro', 'Franca', 'SP', 'Brasil'
);

INSERT INTO address (
    id, cep, street, "number", complement, district, city, uf, country
) VALUES (
    2, '14401-222', 'Rua Ciclano', 222, 'Complemento', 'Leporace 3', 'Franca', 'SP', 'Brasil'
);

INSERT INTO address (
    id, cep, street, "number", complement, district, city, uf, country
) VALUES (
    3, '14401-333', 'Rua Beltrano', 333, 'Complemento', 'Centro', 'São Paulo', 'SP', 'Brasil'
);

-- Inserindo os pedidos
-- DESCRIBE "order";

INSERT INTO "order" (
    id, address_id, customer_id, current_status, current_proccess, title,
    description, installation_environments, start_date, end_date,
    furniture_delivery_forecast, payment_method, gross_value, expenses_value
) VALUES (
    0, 0, 0, 2, 10, 'Armário de cozinha', 'Descrição...', 'Cozinha',
    '01/01/2021', '01/02/2021', '20/01/2021', 'Descrição do pagamento...',
    10000, 4500
);

INSERT INTO "order" (
    id, address_id, customer_id, current_status, current_proccess, title,
    description, installation_environments, start_date, end_date,
    furniture_delivery_forecast, payment_method, gross_value, expenses_value
) VALUES (
    1, 1, 0, 1, 4, 'Guarda roupas infantil', 'Descrição...', 'Quarto do Filho',
    '08/03/2021', '09/04/2021', '24/03/2021', 'Descrição do pagamento...',
    8000, 3250
);

INSERT INTO "order" (
    id, address_id, customer_id, current_status, current_proccess, title,
    description, installation_environments, start_date, end_date,
    furniture_delivery_forecast, payment_method, gross_value, expenses_value
) VALUES (
    2, 2, 2, 0, 2, 'Estante da Sala', 'Descrição...', 'Sala',
    '12/03/2021', null, '28/03/2021', 'Descrição do pagamento...',
    7500, 3000
);

INSERT INTO "order" (
    id, address_id, customer_id, current_status, current_proccess, title,
    description, installation_environments, start_date, end_date,
    furniture_delivery_forecast, payment_method, gross_value, expenses_value
) VALUES (
    3, 3, 2, 2, 2, 'Armário de Varanda', 'Descrição...', 'Varanda',
    '28/08/2021', null, '08/09/2021', 'Descrição do pagamento...',
    12000, 5000
);

-- Inserindo as instalações
-- DESCRIBE installation;

INSERT INTO installation (id, order_id, start_date, end_date, completion_forecast, price)
VALUES (0, 0, '20/01/2021', '30/01/2021', '29/01/2021', 124.99);

INSERT INTO installation (id, order_id, start_date, end_date, completion_forecast, price)
VALUES (1, 1, '24/03/2021', '30/03/2021', '30/03/2021', 119.99);

INSERT INTO installation (id, order_id, start_date, end_date, completion_forecast, price)
VALUES (2, 3, '09/09/2021', null, '11/09/2021', 124.99);

-- Adicionando montador nas instalações
-- DESCRIBE installation_has_assembler;

INSERT INTO installation_has_assembler (installation_id, assembler_id, commission_percentage)
VALUES (0, 3, 10);

INSERT INTO installation_has_assembler (installation_id, assembler_id, commission_percentage)
VALUES (0, 4, 15);

INSERT INTO installation_has_assembler (installation_id, assembler_id, commission_percentage)
VALUES (1, 3, 20);

INSERT INTO installation_has_assembler (installation_id, assembler_id, commission_percentage)
VALUES (2, 3, 12);

INSERT INTO installation_has_assembler (installation_id, assembler_id, commission_percentage)
VALUES (2, 5, 10);

-- Inserindo as avaliações
-- DESCRIBE assessment;

INSERT INTO assessment (
    id, installation_id, cleaning_note, finish_note, customer_note, manager_note, loss_amount, "comment"
) VALUES (
    0, 0, 9, 8, 10, 9, 20, 'Comentário sobre a instalação...'
);

INSERT INTO assessment (
    id, installation_id, cleaning_note, finish_note, customer_note, manager_note, loss_amount, "comment"
) VALUES (
    1, 1, 6, 7, 8, 7, 35, 'Comentário sobre a instalação...'
);

-- Inserindo itens no portfólio
-- DESCRIBE portfolio_item;

INSERT INTO portfolio_item (id, image, title, description)
VALUES (0, 'img1.png', 'Item 1', 'Descrição do item...');

INSERT INTO portfolio_item (id, image, title, description)
VALUES (1, 'img2.png', 'Item 2', 'Descrição do item...');

INSERT INTO portfolio_item (id, image, title, description)
VALUES (2, 'img3.png', 'Item 3', 'Descrição do item...');

-- Commit das alterações
COMMIT;
