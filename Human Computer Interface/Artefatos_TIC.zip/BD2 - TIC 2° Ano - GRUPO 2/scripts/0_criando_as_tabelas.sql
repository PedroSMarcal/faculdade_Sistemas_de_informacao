-- Criando o usuário "tic"
CREATE USER tic IDENTIFIED BY tic_senha;

-- Adicionando a permissão
GRANT connect, resource TO tic;

ALTER USER tic quota 100M on USERS;

-- Criando a tabela User
CREATE TABLE users (
    id          INTEGER,
    name        VARCHAR2(45),
    username    VARCHAR2(30),
    password    VARCHAR2(255),
    CONSTRAINT pk_user_id PRIMARY KEY(id)
);

-- Criando a tabela Admin
CREATE TABLE admin (
    id                      INTEGER,
    permission_create_admin INTEGER,
    CONSTRAINT pk_admin_id PRIMARY KEY(id),
    CONSTRAINT fk_admin_id FOREIGN KEY(id)
        REFERENCES users(id)
);

-- Criando a tabela Assembler
CREATE TABLE assembler (
    id          INTEGER,
    cellphone   VARCHAR(15),
    CONSTRAINT pk_assembler_id PRIMARY KEY(id),
    CONSTRAINT fk_assembler_id FOREIGN KEY(id)
        REFERENCES users(id)
);

-- Criando a tabela ToDo
CREATE TABLE todo (
    id          INTEGER,
    admin_id    INTEGER,
    done        INTEGER,
    title       VARCHAR2(45),
    description VARCHAR2(100),
    CONSTRAINT pk_todo_id PRIMARY KEY(id),
    CONSTRAINT fk_todo_admin_id FOREIGN KEY(admin_id)
        REFERENCES admin(id)
);

-- Criando a tabela Customer
CREATE TABLE customer (
    id                  INTEGER,
    send_contact_alert  INTEGER,
    name                VARCHAR2(30),
    phone               VARCHAR2(15),
    document            VARCHAR2(18),
    next_contact_date   DATE,
    CONSTRAINT pk_customer_id PRIMARY KEY(id)
);

-- Criando a tabela Address
CREATE TABLE address (
    id          INTEGER,
    cep         CHAR(9),
    street      VARCHAR2(100),
    "number"    INTEGER,
    complement  VARCHAR2(50),
    district    VARCHAR2(60),
    city        VARCHAR2(45),
    uf          CHAR(2),
    country     VARCHAR2(45),
    CONSTRAINT pk_address_id PRIMARY KEY(id)
);

-- Criando a tabela Order
CREATE TABLE "order" (
    id                          INTEGER,
    address_id                  INTEGER,
    customer_id                 INTEGER,
    current_status              INTEGER,
    current_proccess            INTEGER,
    title                       VARCHAR2(30),
    description                 VARCHAR2(100),
    installation_environments   VARCHAR2(60),
    start_date                  DATE,
    end_date                    DATE,
    furniture_delivery_forecast DATE,
    payment_method              VARCHAR2(60),
    gross_value                 NUMERIC,
    expenses_value              NUMERIC,
    CONSTRAINT pk_order_id PRIMARY KEY(id),
    CONSTRAINT fk_order_address_id FOREIGN KEY(address_id)
        REFERENCES address(id),
    CONSTRAINT fk_order_customer_id FOREIGN KEY(customer_id)
        REFERENCES customer(id)
);

-- Criando a tabela Installation
CREATE TABLE installation (
    id                  INTEGER,
    order_id            INTEGER,
    start_date          DATE,
    end_date            DATE,
    completion_forecast DATE,
    price               NUMERIC,
    CONSTRAINT pk_installation_id PRIMARY KEY(id),
    CONSTRAINT fk_installation_order_id FOREIGN KEY(order_id)
        REFERENCES "order"(id)
);

-- Criando a tabela Installation Has Assembler
CREATE TABLE installation_has_assembler (
    installation_id         INTEGER,
    assembler_id            INTEGER,
    commission_percentage   INTEGER,
    CONSTRAINT pk_instal_assemb_install_id_assemb_id
        PRIMARY KEY(installation_id, assembler_id),
    CONSTRAINT fk_instal_assemb_installation_id
        FOREIGN KEY(installation_id)
        REFERENCES installation(id),
    CONSTRAINT fk_instal_assemb_assembler_id
        FOREIGN KEY(assembler_id)
        REFERENCES assembler(id)
);

-- Criando a tabela Installation Assessment
CREATE TABLE assessment (
    id                  INTEGER,
    installation_id     INTEGER,
    cleaning_note       INTEGER,
    finish_note         INTEGER,
    customer_note       INTEGER,
    manager_note        INTEGER,
    loss_amount         DECIMAL,
    "comment"           VARCHAR2(100),
    CONSTRAINT pk_instal_asses_id PRIMARY KEY(id),
    CONSTRAINT fk_instal_asses_installation_id
        FOREIGN KEY(installation_id)
        REFERENCES installation(id)
);

-- Criando a tabela Portfolio Item
CREATE TABLE portfolio_item (
    id          INTEGER,
    image       VARCHAR2(50),
    title       VARCHAR2(45),
    description VARCHAR2(100),
    CONSTRAINT pk_portfolio_item_id PRIMARY KEY(id)
);
