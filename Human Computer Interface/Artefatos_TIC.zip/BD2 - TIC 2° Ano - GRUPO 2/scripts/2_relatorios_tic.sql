-- 1) Título: Selecionando o id e título dos pedidos com instalações atrasadas de uma certa cidade
    -- Teste com a cidade: Franca
ACCEPT v_city CHAR FORMAT A45 PROMPT 'Entre com o nome da cidade';

SELECT o.id "Identificador", o.title "Título do Pedido" FROM address a
INNER JOIN "order" o ON (a.id = o.address_id)
INNER JOIN installation i ON (o.id = i.order_id)
WHERE i.end_date > i.completion_forecast AND a.city = '&v_city';

-- 2) Título: Listando o título e os valores, juntamente com o cálculo do lucro, de todos os pedidos cadastrados (sem contar as comissões pagas aos instaladores)
SELECT 
    o.title "Título do Pedido",
    o.gross_value "Valor Bruto",
    o.expenses_value "Valor em Despesa",
    NVL(i.price, 0) "Preço da Instalação",
    NVL(a.loss_amount, 0) "Valor de Perda na Obra",
    (o.gross_value - o.expenses_value - NVL(i.price, 0) - NVL(a.loss_amount, 0)) "Lucro Total (Sem contar a comissão)"
FROM "order" o
LEFT OUTER JOIN installation i ON o.id = i.order_id
LEFT OUTER JOIN assessment a ON i.id = a.installation_id;

-- 3) Título: Recuperando os instaladores e o valor que cada um recebeu pelas instalações que realizou (sem contar as comissões)
SELECT u.name "Nome do Montador", SUM(i.price) "Valor Recebido (Sem contar a comissão)" FROM users u
INNER JOIN assembler a ON a.id = u.id
INNER JOIN installation_has_assembler ia ON a.id = ia.assembler_id
INNER JOIN installation i ON ia.installation_id = i.id
GROUP BY u.name;
