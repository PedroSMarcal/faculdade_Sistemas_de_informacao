// Configurações da autenticação
export default {
  token: {
    secret: 'default',
    expiresIn: '1d',
  },
};
