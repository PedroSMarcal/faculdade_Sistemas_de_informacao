import { createConnection } from 'typeorm';

// Criando a conexão com o banco de dados
createConnection();
