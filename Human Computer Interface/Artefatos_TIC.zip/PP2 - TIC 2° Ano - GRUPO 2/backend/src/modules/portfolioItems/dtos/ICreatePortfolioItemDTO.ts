interface ICreatePortfolioItemDTO {
  id?: string;
  image_reference: string;
  title: string;
  description: string;
}

export default ICreatePortfolioItemDTO;
