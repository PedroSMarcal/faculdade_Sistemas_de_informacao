interface IDatePropsDTO {
  day: number;
  month: number;
  year: number;
}

export default IDatePropsDTO;
