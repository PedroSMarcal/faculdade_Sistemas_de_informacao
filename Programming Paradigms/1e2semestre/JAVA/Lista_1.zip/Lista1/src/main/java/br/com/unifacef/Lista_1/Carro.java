package br.com.unifacef.Lista_1;
// Serve de Modelo
/**
 * @author pedro
 */

public class Carro {
    // Classe é com Iniciais Maisculas
    // primitivo só atribui um valor
    // Declaração de Variaveis
    // Java possui tipagem estática, é forte
    String Marca; // String é uma classe 
    String Modelo; // String é uma classe
    int Ano; // int é primtivo, Integer é classe
    boolean Motor; // boolean é um tipo primitivo
    float VelAtual; // float tipo primitivo 
}

