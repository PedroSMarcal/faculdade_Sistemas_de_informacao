package br.com.unifacef.Lista_1;
// Serve de Modelo

import javax.swing.JOptionPane;

/**
 * @author pedro
 */

public class Carro {
    // Classe é com Iniciais Maisculas
    // primitivo só atribui um valor
    // Declaração de Variaveis
    // Java possui tipagem estática, é forte
    String Marca; // String é uma classe 
    String Modelo; // String é uma classe
    int Ano; // int é primtivo, Integer é classe
    boolean Motor; // boolean é um tipo primitivo
    float VelAtual; // float tipo primitivo 
    //Metodo construtor
    public Carro (String Marca, String Modelo, int Ano, boolean motor, float VelAtual){
        this.Ano = Ano;
        this.Marca = Marca; 
        
        // This serve para representar o elemento nele mesmo
    }
           
    public Carro () {
        
    }

    public void Mostra(){
        System.out.println("Ano: " + this.Ano + "\n Marca" + this.Marca + "\n Motor" + this.Motor + "\n VelAtual: " + this.VelAtual 
                + "\n Modelo" + this.Modelo);
    }
    
    public void MostraPanel(){
        JOptionPane.showMessageDialog(null, "Marca: " + this.Marca + "\n Motor: " + this.Motor + 
                "\n Velocidade_Atual: " + this.VelAtual + "\n Modelo: " + this.Modelo + "\n Ano: " + this.Ano);
    }
    
    public void CarOn(){
        if (!this.Motor){
             this.Motor = true;
        }
    }
    public void Desligar (){
        if (this.Motor){
            this.Motor = false;
            this.VelAtual = 0;
        }
    }
    public void Acelerar (float x) {
        if (this.Motor){
            this.VelAtual = this.VelAtual + x;
        }
    }
    public void Frear (float x) {
        if (this.Motor){
            if (this.VelAtual >= x){
                this.VelAtual = this.VelAtual - x;
            }
            else{
                System.out.println("velocidade negativa");
            }
        }
        else{
            System.out.println("motorDesligado");
        }
    }
}

