// RESPONSAVEL PELO BANCO DE DADOS 
// importar a função createConnection
import { createConnection } from "typeorm";

createConnection(); //cria conexão com o banco