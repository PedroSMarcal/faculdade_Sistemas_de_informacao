export default function Posts(){
    return <h1> Posts </h1>
}